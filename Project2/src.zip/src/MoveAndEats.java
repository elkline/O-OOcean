public interface MoveAndEats extends AnimatedEntity{

}
