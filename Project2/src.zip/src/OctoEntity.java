public interface OctoEntity extends MoveAndEats{
}
