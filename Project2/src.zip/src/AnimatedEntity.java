public interface AnimatedEntity extends ActiveEntity{

    public int getAnimationPeriod();

}
